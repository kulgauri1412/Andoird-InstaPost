package com.example.demo4

class Users {


    var id: String = ""
    var name: String = ""
    var nickName: String = ""
    var email: String = ""
    var password: String = ""

    constructor() : this("", "", "", "", "") {

    }

    constructor(id: String, name: String, nickName: String, email: String, password: String) {
        this.id = id
        this.name = name
        this.nickName = nickName
        this.email = email
        this.password = password
    }

}