package com.example.demo4

class HashTags {
    var hashtagId: String = ""
    var hashtag: String = ""
    var imageUrl: String = ""
    // var ImageuploadId : String = ""

    constructor(hashtagId: String, hashtag: String, imageUrl: String) {
        this.hashtagId = hashtagId
        this.hashtag = hashtag
        this.imageUrl = imageUrl
        //  this.ImageuploadId = ImageuploadId
    }

    constructor() : this("", "", "") {

    }

}