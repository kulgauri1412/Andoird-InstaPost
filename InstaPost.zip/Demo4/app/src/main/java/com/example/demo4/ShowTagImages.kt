package com.example.demo4

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.squareup.picasso.Picasso

class ShowTagImages : AppCompatActivity() {

    lateinit var mAuth: FirebaseAuth
    lateinit var mDatabase: DatabaseReference
    lateinit var tagImageView: RecyclerView
    var imageUrl: String = ""
    //lateinit var adapter : ImageAdapter
    var images: String = ""
    // lateinit var textView3 : TextView
    val imagetaglist = ArrayList<String>()
    val taglist = ArrayList<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_tag_images)

        val hashtagInfo = intent.extras
        val hashtags = hashtagInfo.getString("hashtagName")
        val hashtagid = hashtagInfo.getString("hashid")
        DisplayTagImages()

        tagImageView = findViewById(R.id.tagImageView) as RecyclerView
        tagImageView.layoutManager = LinearLayoutManager(this) as RecyclerView.LayoutManager?


    }

    fun DisplayTagImages() {

        val hashtagInfo = intent.extras
        val hashtags = hashtagInfo.getString("hashtagName")
        val hashtagid = hashtagInfo.getString("hashid")

        mDatabase = FirebaseDatabase.getInstance().getReference()
        var query = mDatabase.child("Users")
        var option = FirebaseRecyclerOptions.Builder<CollectPosts>()
            .setQuery(query, CollectPosts::class.java)
            .build()

        query.addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(p0: DataSnapshot) {

                for (users in p0.children) {

                    val userinfo = users.getValue(Users::class.java)
                    val uid = userinfo?.id.toString()

                    Log.e("info", "userid: $uid")



                    query.child(uid).child("Posts").addValueEventListener(object : ValueEventListener {
                        override fun onCancelled(p0: DatabaseError) {

                        }

                        override fun onDataChange(p0: DataSnapshot) {

                            if (p0.exists()) {
                                for (hashdata in p0.children) {

                                    val hashinfo = hashdata.getValue(Posts::class.java)
                                    val hashtagList = hashinfo?.hashtags
                                    val tags = hashinfo?.tags.toString()

                                    Log.e("info", "Hashinfo : $hashtags")

                                    if (hashtagList != null) {
                                        for (hash in hashtagList) {
                                            Log.e("info", "Hashinfo : $hash")

                                            if (hashtags == hash) {

                                                images = hashinfo.imageUrl

                                                imagetaglist.add(images)
                                                taglist.add(tags)
                                                Log.e("info", "tag:$tags, image: $images")
                                                //textView3.text = images
                                                //var FirebaseRecyclerOptions = object  : FirebaseRecyclerAdapter<Posts,>
                                            }


                                        }

                                    }

                                }
                                tagImageView.adapter = ImageAdapter(imagetaglist, taglist, this@ShowTagImages)
                                Log.e("indfo", "size ${imagetaglist}")
                            } else {
                                Log.e("info", "Hashinfo null")
                            }
                        }


                    })


                }

            }


        })


    }

    class ImageAdapter(val ittem: ArrayList<String>,val tags :ArrayList<String>, val ctx: ShowTagImages) : RecyclerView.Adapter<PostViewHolder>() {
        // var imagelist = ittem
        //var context = ctx

        override fun getItemCount(): Int {
            return ittem.size
        }

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): PostViewHolder {
            val list = LayoutInflater.from(ctx).inflate(R.layout.user_tag_image_view, parent, false)
            return PostViewHolder(list)
        }


        override fun onBindViewHolder(
            holder: PostViewHolder,
            position: Int
        ) {

            Log.e("info", "list : ${ittem.size}")
            var tag = tags.get(position)

            holder.caption.text =tag

            var list = ittem.get(position)

            Picasso.get().load(list).into(holder.image)


            // Picasso.get(imagelist(position)).load(imagelist).into(holder.image)
        }

    }

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        internal var image = itemView?.findViewById<ImageView>(R.id.imageTagPostView)
        internal var caption = itemView?.findViewById<TextView>(R.id.tagcaption)
        //internal var nickname = itemView?.findViewById<TextView>(R.id.postNickname)
        // internal var download = itemView?.findViewById<Button>(R.id.download)

    }


    //Menu items
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        var selectedOption = ""
        when (item?.itemId) {

            R.id.itemUsers -> return showUsers()
            R.id.itemTags -> return showTags()
            R.id.home -> return dashobard()
            R.id.itemLogout -> return Logout()
        }
        Toast.makeText(this, "Options: " + selectedOption, Toast.LENGTH_SHORT).show()

        return super.onOptionsItemSelected(item)
    }

    fun dashobard(): Boolean {
        val intent = Intent(applicationContext, DashboardActivity::class.java)
        startActivity(intent)
        return true
    }

    fun showTags(): Boolean {
        val intent = Intent(applicationContext, ShowTags::class.java)
        startActivity(intent)
        return true

    }

    fun showUsers(): Boolean {

        val intent = Intent(applicationContext, ShowUsers::class.java)
        startActivity(intent)
        return true
    }

    fun Logout(): Boolean {

        val intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
        finish()
        return true
    }
}




