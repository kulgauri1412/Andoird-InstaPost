package com.example.demo4

//import jdk.nashorn.internal.runtime.ECMAException.getException
//import org.junit.experimental.results.ResultMatchers.isSuccessful
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*


@Suppress("DEPRECATION")
class SignupActivity : AppCompatActivity() {

    lateinit var userSignup: Button
    lateinit var userName: EditText
    lateinit var userNickName: EditText
    lateinit var userEmail: EditText
    lateinit var userPassword: EditText


    lateinit var mAuth: FirebaseAuth
    lateinit var mDatabase: DatabaseReference
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        mAuth = FirebaseAuth.getInstance()
        //  mDatabase = FirebaseDatabase.getInstance().getReference("Users")

        progressDialog = ProgressDialog(this)


        userSignup = findViewById(R.id.userSignup)
        userName = findViewById(R.id.userName)
        userNickName = findViewById(R.id.userNickName)
        userEmail = findViewById(R.id.userEmail)
        userPassword = findViewById(R.id.userPassword)


        // progressBar = findViewById(R.id.progressBar)

        userSignup.setOnClickListener {

            /* var name = userName.text.toString().trim()
             var nickName = userNickName.text.toString().trim()
             var email = userEmail.text.toString().trim()
             var password = userPassword.text.toString().trim()*/

            userRegister()
        }
    }

    fun userRegister() {

        progressDialog.setMessage("Please wait..")
        progressDialog.show()

        var name = userName.text.toString().trim()
        var nickname = userNickName.text.toString().trim()
        var email = userEmail.text.toString().trim()
        var password = userPassword.text.toString().trim()

        if (name.isEmpty()) {
            Toast.makeText(this, "Enter name!", Toast.LENGTH_SHORT).show()
            progressDialog.dismiss()
            return
        }
        if (nickname.isEmpty()) {
            Toast.makeText(this, "Enter nick name!", Toast.LENGTH_SHORT).show()
            progressDialog.dismiss()
            return
        }
        if (email.isEmpty()) {
            Toast.makeText(this, "Enter email id!", Toast.LENGTH_SHORT).show()
            progressDialog.dismiss()
            return
        }
        if (password.isEmpty()) {
            Toast.makeText(this, "Enter password!", Toast.LENGTH_SHORT).show()
            progressDialog.dismiss()
            return
        }

        var uniquenickname =
            FirebaseDatabase.getInstance().getReference("Users").orderByChild("nickName").equalTo(nickname)

        uniquenickname.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(p0: DataSnapshot) {

                if (p0.childrenCount > 0) {
                    Toast.makeText(this@SignupActivity, "Select different nickname!", Toast.LENGTH_SHORT).show()
                    progressDialog.dismiss()
                } else {

                    mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {

                                val currebtUser = FirebaseAuth.getInstance().currentUser
                                val uid: String = currebtUser?.uid.toString()

                                // var id = mAuth.getUid()

                                mDatabase = FirebaseDatabase.getInstance().getReference("Users")
                                // val id : String  = mDatabase.push().key.toString()

                                val users = Users(uid, name, nickname, email, password)

                                // mDatabase.child(id).setValue(users)

                                /* val userMap = HashMap<String,String>()
                                 userMap["name"] = name
                                 userMap["id"] = id
                                 userMap["nickname"] = nickname
                                 userMap["email"] = email
                                 userMap["password"] = password
                                */


                                //mDatabase.push().setValue("userid",id)

                                mDatabase.child(uid).setValue(users).addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        Toast.makeText(this@SignupActivity, "User Registred!!", Toast.LENGTH_SHORT)
                                            .show()
                                        val intent = Intent(applicationContext, MainActivity::class.java)
                                        startActivity(intent)
                                    } else {
                                        Toast.makeText(
                                            this@SignupActivity, "Authentication failed.Please try again later",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        progressDialog.dismiss()
                                    }
                                } /*{
                        task -> {
                        if(task.isSuccessful){
                            val intent = Intent(applicationContext,DashboardActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }
                    }*/

                            } else {
                                // If sign in fails, display a message to the user.
                                //Log.w(FragmentActivity.TAG, "createUserWithEmail:failure", task.exception)

                                Toast.makeText(
                                    this@SignupActivity, "Authentication failed.",
                                    Toast.LENGTH_SHORT
                                ).show()
                                progressDialog.dismiss()
                            }

                            // ...
                        }

                }
            }


        })


        /*if(userName.text.toString().length > 0 && userNickName.text.toString().length > 0 && userEmail.text.toString().length > 0 && userPassword.text.toString().length > 0)
        {
            Log.i("tag","name : ${userName.text.toString()}")
            Log.i("tag","nickname : ${userNickName.text.toString()}")
            Log.i("tag","email : ${userEmail.text.toString()}")
            Log.i("tag","password : ${userPassword.text.toString()}")
            Toast.makeText(this,"User Sign up successfully!!",Toast.LENGTH_SHORT).show()
            finish()
        }
        else{

            Toast.makeText(this,"Sign Up failed..",Toast.LENGTH_SHORT).show()
        }*/

    }
}
