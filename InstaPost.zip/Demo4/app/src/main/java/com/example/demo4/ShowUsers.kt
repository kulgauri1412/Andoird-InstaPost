package com.example.demo4

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ShowUsers : AppCompatActivity() {

    lateinit var userView: RecyclerView
    lateinit var mAuth: FirebaseAuth
    lateinit var mDatabase: DatabaseReference
    lateinit var progressBar: ProgressBar
    lateinit var showUserList: MutableList<Users>
    lateinit var check: RelativeLayout
    var nickname: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_users)


        //progressBar = findViewById(R.id.progressBar)
        //showUserList = mutableListOf()
        mDatabase = FirebaseDatabase.getInstance().getReference()
        userView = findViewById(R.id.userView)
        userView.layoutManager = LinearLayoutManager(this) as RecyclerView.LayoutManager?

        //firebaseData()
        DisplayUsers()
    }

    fun DisplayUsers() {

        var query = mDatabase.child("Users")
        var option = FirebaseRecyclerOptions.Builder<Users>()
            .setQuery(query, Users::class.java)
            .build()

        Log.e("tag", "db : $query")
        var FirebaseRecyclerAdapter = object : FirebaseRecyclerAdapter<Users, UsersViewHolder>(
            option

        ) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsersViewHolder {
                val list = LayoutInflater.from(this@ShowUsers).inflate(R.layout.user_card_view, parent, false)
                return UsersViewHolder(list)
            }

            override fun onBindViewHolder(p0: UsersViewHolder, p1: Int, p2: Users) {

                val currebtUser = FirebaseAuth.getInstance().currentUser
                val uid: String = currebtUser?.uid.toString()

                if (p2.id == uid) {

                    p0.userName.setTextColor(Color.RED)
                    p0.userName.setText(p2.name)
                    p0.usernickname.text = "( " + p2.nickName + " )"
                    // userView.isVisible = false
                    Log.i("tag", "Current user")
                    //p0.userName.setText(p2.name)
                    //p0.uId.setText(p2.id)
                    // p0.userName.setText(p2.name)
                } else {

                    //userView.isVisible =true
                    p0.userName.setText(p2.name)
                    p0.uId.setText(p2.id)
                    p0.usernickname.text = "( " + p2.nickName + " )"

                }

                p0.itemView.setOnClickListener {
                    val currebtUser = FirebaseAuth.getInstance().currentUser
                    val uid: String = currebtUser?.uid.toString()
                    if (p2.id == uid) {
                        Toast.makeText(this@ShowUsers, "This is you !!", Toast.LENGTH_SHORT).show()
                        Log.i("Tag", "Show : Current User")
                    } else {

                        val showposts = Intent(applicationContext, ShowPosts::class.java)
                        showposts.putExtra("userid", p2.id)
                        showposts.putExtra("nickname", p2.nickName)
                        startActivity(showposts)
                        Log.i("tag", "Show ${p2.id} | ${p2.nickName}")
                    }


                }

            }

        }

        userView.adapter = FirebaseRecyclerAdapter
        FirebaseRecyclerAdapter.startListening()

    }


    class UsersViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        internal var userName = itemView?.findViewById<TextView>(R.id.listUserName)
        internal var uId = itemView?.findViewById<TextView>(R.id.listUserId)
        internal var usernickname = itemView?.findViewById<TextView>(R.id.listUserNickname)

    }

    /* fun firebaseData(){

         val options = FirebaseRecyclerOptions.Builder<Users>()
             .setQuery(mDatabase,Users::class.java)
             .build()

         val firebaseAdapter = object : FirebaseRecyclerAdapter<Users,MyViewHolder>(options){

             override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
                 val itemView = LayoutInflater.from(this@ShowUsers).inflate(R.layout.user_card_view,parent,false)
                 return MyViewHolder(itemView)
             }
             override fun onBindViewHolder(holder: MyViewHolder, p1: Int, p2: Users) {

                 mDatabase.addValueEventListener(object :ValueEventListener{
                     override fun onCancelled(p0: DatabaseError) {
                         TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                     }

                     override fun onDataChange(p0: DataSnapshot) {
                         progressBar.visibility = if(itemCount == 0)View.VISIBLE else View.GONE

                         holder.userName.setText(p2.name)
                         holder.uId.setText(p2.id)

                         holder.itemView.setOnClickListener {

                             val intent = Intent(this@ShowUsers,DashboardActivity::class.java)
                             startActivity(intent)
                         }
                     }

                 })
             }

         }

         userView.adapter = firebaseAdapter
         firebaseAdapter.startListening()

     }*/


    /* class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){

         internal var userName = itemView?.findViewById<TextView>(R.id.listUserName)
         internal var uId = itemView?.findViewById<TextView>(R.id.listUserId)
     }*/

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        var selectedOption = ""
        when (item?.itemId) {

            R.id.itemUsers -> return showUsers()
            R.id.itemTags -> return showTags()
            R.id.home -> return dashobard()
            R.id.itemLogout -> return Logout()
        }
        Toast.makeText(this, "Options: " + selectedOption, Toast.LENGTH_SHORT).show()

        return super.onOptionsItemSelected(item)
    }

    fun dashobard(): Boolean {
        val intent = Intent(applicationContext, DashboardActivity::class.java)
        startActivity(intent)
        return true
    }

    fun showTags(): Boolean {
        val intent = Intent(applicationContext, ShowTags::class.java)
        startActivity(intent)
        return true

    }

    fun showUsers(): Boolean {

        val intent = Intent(applicationContext, ShowUsers::class.java)
        startActivity(intent)
        return true
    }

    fun Logout(): Boolean {

        val intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
        finish()
        return true
    }
}
