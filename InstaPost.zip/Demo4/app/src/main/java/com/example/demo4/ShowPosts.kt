package com.example.demo4

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.squareup.picasso.Picasso


//import javax.activation.CommandObject


class ShowPosts : AppCompatActivity() {

    lateinit var mAuth: FirebaseAuth
    lateinit var mDatabase: DatabaseReference
    lateinit var postView: RecyclerView
    lateinit var saveIurl: String
    private val STORAGE_PERMISSION_CODE = 1000
    private val PERMISSION_CODE = 1001
    private val IMAGE_PICK_CODE = 1002
    private var postUserNickname: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_posts)

        val personData = intent.extras
        val userid = personData.getString("userid")
        postUserNickname = personData.getString("nickname")


        postView = findViewById(R.id.postView)
        postView.layoutManager = LinearLayoutManager(this) as RecyclerView.LayoutManager?

        Log.i("tag", "current : $userid")

        displayPosts()
    }

    private fun displayPosts() {

        val personData = intent.extras
        val userid = personData.getString("userid")
        mDatabase = FirebaseDatabase.getInstance().getReference()

        var query = mDatabase.child("Users").child(userid).child("Posts").orderByValue()

        Log.e("tag", "db : $query")
        var option = FirebaseRecyclerOptions.Builder<CollectPosts>()
            .setQuery(query, CollectPosts::class.java)
            .build()

        var FirebaseRecyclerAdapter = object : FirebaseRecyclerAdapter<CollectPosts, PostViewHolder>(option) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {

                val list = LayoutInflater.from(this@ShowPosts).inflate(R.layout.user_post_view, parent, false)
                return PostViewHolder(list)
            }

            override fun onBindViewHolder(p0: PostViewHolder, p1: Int, p2: CollectPosts) {

                // Toast.makeText(this@ShowPosts,"Inside ",Toast.LENGTH_SHORT).show()

                Log.e("tag", "id : ${p2.imageId} , ${p2.tags} , ${p2.imageUrl}")
                //p0.nickname.text =p2.nickName
                p0.nickname.text = resources.getString(R.string.nickname) + postUserNickname
                p0.caption.text = p2.tags
                Picasso.get().load(p2.imageUrl).into(p0.image)
//                var a = p2.tags.toString()

                /* p0.download.setOnClickListener {

                     saveIurl = p2.imageUrl

                     saveImage()
                 }*/
                //holder.caption.setText(a)
                // Picasso.get().load(p2.imageUrl).into(holder.imagePostView)

                /*  mDatabase.addValueEventListener(object : ValueEventListener{
                      override fun onCancelled(p0: DatabaseError) {

                      }

                      override fun onDataChange(p0: DataSnapshot) {

//                             var test:String = p0.child("tags").getValue() as String
                          //holder.caption.setText(p2.tags)
                          //Log.i("tag","caption $test")
                          /*for (datas in p0.getChildren()) {
                              val msgContent = datas.child("tags").getValue()!!.toString()
                           //   val msgType = datas.child("msgType").getValue()!!.toString()

                              holder.caption.setText(msgContent)
                          }*/
                      }

                  })*/
            }

        }
        postView.adapter = FirebaseRecyclerAdapter
        FirebaseRecyclerAdapter.startListening()

    }

    /*class PostViewHolder(itemView: View):RecyclerView .ViewHolder(itemView){

        internal var imagePostView = itemView?.findViewWithTag<ImageView>(R.id.imagePostView)
        internal var caption = itemView?.findViewWithTag<TextView>(R.id.caption)
    }*/

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        internal var image = itemView?.findViewById<ImageView>(R.id.imagePostView)
        internal var caption = itemView?.findViewById<TextView>(R.id.caption)
        internal var nickname = itemView?.findViewById<TextView>(R.id.postNickname)
        // internal var download = itemView?.findViewById<Button>(R.id.download)

    }

    //Save image to you're local device
    fun saveImage() {

        Toast.makeText(applicationContext, "Url : $saveIurl", Toast.LENGTH_SHORT).show()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                //permission denied

                requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), STORAGE_PERMISSION_CODE)

            } else {
                //permission already grated
                startDownload()
            }
        } else {
            // system os is less than marshmallow
            startDownload()
        }

        //Read permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                //permission denied
                val permission = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                //show popup
                requestPermissions(permission, PERMISSION_CODE)
            } else {
                //permission already granted

                checkImage()
            }
        } else {
            //system os is < Marshmallow
            checkImage()
        }
    }

    fun checkImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "SELECT IMAGE"), IMAGE_PICK_CODE)
    }

    fun startDownload() {

        //Toast.makeText(this,"Url: $saveIurl",Toast.LENGTH_SHORT).show()

        //download request
        val request = DownloadManager.Request(Uri.parse(saveIurl))
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
        request.setTitle("Download")
        request.setDescription("Image is downloading..")
        request.allowScanningByMediaScanner()
        // request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "${System.currentTimeMillis()}")

        //get download
        val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)

        Toast.makeText(this, "Image successfully downloaded!!", Toast.LENGTH_SHORT).show()

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            STORAGE_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startDownload()

                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                }
            }
            PERMISSION_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkImage()
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                }
            }

        }
    }

    //Menu items
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        var selectedOption = ""
        when (item?.itemId) {

            R.id.itemUsers -> return showUsers()
            R.id.itemTags -> return showTags()
            R.id.home -> return dashobard()
            R.id.itemLogout -> return Logout()
        }
        Toast.makeText(this, "Options: " + selectedOption, Toast.LENGTH_SHORT).show()

        return super.onOptionsItemSelected(item)
    }

    fun dashobard(): Boolean {
        val intent = Intent(applicationContext, DashboardActivity::class.java)
        startActivity(intent)
        return true
    }

    fun showTags(): Boolean {
        val intent = Intent(applicationContext, ShowTags::class.java)
        startActivity(intent)
        return true

    }

    fun showUsers(): Boolean {

        val intent = Intent(applicationContext, ShowUsers::class.java)
        startActivity(intent)
        return true
    }

    fun Logout(): Boolean {

        val intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
        finish()
        return true
    }
}
