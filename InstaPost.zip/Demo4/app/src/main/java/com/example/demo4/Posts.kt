package com.example.demo4

class Posts {

    var imageId: String = ""
    var imageUrl: String = ""
    var tags: String = ""
    var uid: String = ""
    lateinit var hashtags: ArrayList<String>

    constructor() : this("", "", "", "", arrayListOf<String>()) {

    }

    constructor(imageId: String, imageUrl: String, tags: String, uid: String, hashtags: ArrayList<String>) {

        this.imageId = imageId
        this.imageUrl = imageUrl
        this.tags = tags
        this.uid = uid
        this.hashtags = hashtags
    }


}