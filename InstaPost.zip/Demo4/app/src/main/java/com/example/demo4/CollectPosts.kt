package com.example.demo4

class CollectPosts {

    var id : String = ""
    var name : String = ""
    var nickName : String = ""
    var email : String = ""
    var password : String = ""
    var imageId :String  = ""
    var imageUrl : String = ""
    var tags : String =""
    lateinit var hashtags : ArrayList<String>

    constructor():this("","","","","","","","", arrayListOf()) {

    }

    constructor(id : String, name : String ,nickName : String, email : String, password : String,imageId : String , imageUrl : String , tags : String,hashtags : ArrayList<String>)
    {
        this.id = id
        this.name = name
        this.nickName = nickName
        this.email = email
        this.password = password
        this.imageId = imageId
        this.imageUrl = imageUrl
        this.tags = tags
        this.hashtags = hashtags
    }
}