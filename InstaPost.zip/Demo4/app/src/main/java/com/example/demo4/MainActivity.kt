package com.example.demo4

//import jdk.nashorn.internal.runtime.ECMAException.getException
//import org.junit.experimental.results.ResultMatchers.isSuccessful
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class MainActivity : AppCompatActivity() {

    lateinit var btnLogin: Button
    lateinit var btnSignup: Button
    lateinit var emailId: EditText
    lateinit var password: EditText

    lateinit var mAuth: FirebaseAuth
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mAuth = FirebaseAuth.getInstance()

        btnLogin = findViewById(R.id.btnLogin)
        btnSignup = findViewById(R.id.btnSignup)
        emailId = findViewById(R.id.emailid)
        password = findViewById(R.id.password)

        progressDialog = ProgressDialog(this)

        btnLogin.setOnClickListener {

            var userEmail = emailId.text.toString().trim()
            var userPassword = password.text.toString().trim()

            loginActivity(userEmail, userPassword)
        }

        btnSignup.setOnClickListener {

            signupActivity()
        }
    }

    override fun onStart() {
        super.onStart()

        val currentUser = FirebaseAuth.getInstance().currentUser

        if (currentUser == null) {

            val intent = Intent(applicationContext, SignupActivity::class.java)
            startActivity(intent)
            finish()
        } else {

        }

    }

    fun loginActivity(userEmail: String, userPassword: String) {
        progressDialog.setMessage("Please wait..")
        progressDialog.show()

        if (userEmail.isEmpty()) {

            Toast.makeText(this, "Enter emailid", Toast.LENGTH_SHORT).show()
            return
        }
        if (userPassword.isEmpty()) {

            Toast.makeText(this, "Enter password", Toast.LENGTH_SHORT).show()
            return
        }

        mAuth.signInWithEmailAndPassword(userEmail, userPassword)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    progressDialog.dismiss()
                    var dashboardIntent = Intent(this, DashboardActivity::class.java)
                    startActivity(dashboardIntent)
                    //finish()

                    // Sign in success, update UI with the signed-in user's information
                    //Log.d(FragmentActivity.TAG, "signInWithEmail:success")
                    // val user = mAuth.currentUser
                    //updateUI(user)

                } else {
                    // If sign in fails, display a message to the user.
                    //Log.w(FragmentActivity.TAG, "signInWithEmail:failure", task.exception)
                    Toast.makeText(
                        this, "Authentication failed.",
                        Toast.LENGTH_SHORT
                    ).show()
                    //updateUI(null)

                }
                progressDialog.dismiss()

                // ...
            }


    }

    fun signupActivity() {

        var signupIntent = Intent(this, SignupActivity::class.java)
        startActivity(signupIntent)
        finish()
    }
}
