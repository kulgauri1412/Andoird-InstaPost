package com.example.demo4

class Images {

    var imgeUrl: String = ""
    var imgId: String = ""
    var Imageuploadid: String = ""

    constructor(imgeUrl: String, imgId: String, Imageuploadid: String) {
        this.imgeUrl = imgeUrl
        this.imgId = imgId
        this.Imageuploadid = Imageuploadid
    }

    constructor() : this("", "", "") {

    }
}