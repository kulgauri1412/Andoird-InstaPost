package com.example.demo4

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ShowTags : AppCompatActivity() {

    lateinit var tagView: RecyclerView
    lateinit var mAuth: FirebaseAuth
    lateinit var mDatabase: DatabaseReference
    lateinit var progressBar: ProgressBar
    lateinit var checkTags: RelativeLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_tags)

        mDatabase = FirebaseDatabase.getInstance().getReference()
        tagView = findViewById(R.id.tagView)
        tagView.layoutManager = LinearLayoutManager(this) as RecyclerView.LayoutManager?

        DisplayTags()
    }

    fun DisplayTags() {

        var query = mDatabase.child("Hashtags")
        var option = FirebaseRecyclerOptions.Builder<HashTags>()
            .setQuery(query, HashTags::class.java)
            .build()

        var FirebaseRecyclerAdapter = object : FirebaseRecyclerAdapter<HashTags, TagViewHolder>(option) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TagViewHolder {
                val list = LayoutInflater.from(this@ShowTags).inflate(R.layout.user_tags_view, parent, false)
                return TagViewHolder(list)
            }

            override fun onBindViewHolder(holder: TagViewHolder, p1: Int, p2: HashTags) {

                holder.userName.setText(p2.hashtag)

                holder.userName.setOnClickListener({

                    Toast.makeText(this@ShowTags, "${p2.hashtag}", Toast.LENGTH_SHORT).show()
                    var intent = Intent(this@ShowTags, ShowTagImages::class.java)
                    intent.putExtra("hashtagName", p2.hashtag)
                    intent.putExtra("hashid", p2.hashtagId)
                    startActivity(intent)
                })

            }

        }
        tagView.adapter = FirebaseRecyclerAdapter
        FirebaseRecyclerAdapter.startListening()
    }

    class TagViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        internal var userName = itemView?.findViewById<TextView>(R.id.listHashtag)
        internal var uId = itemView?.findViewById<TextView>(R.id.listHashtagId)

    }

    //Menu

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true

    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        var selectedOption = ""
        when (item?.itemId) {

            R.id.itemUsers -> return showUsers()
            R.id.itemTags -> return showTags()
            R.id.home -> return dashobard()
            R.id.itemLogout -> return Logout()
        }
        Toast.makeText(this, "Options: " + selectedOption, Toast.LENGTH_SHORT).show()

        return super.onOptionsItemSelected(item)
    }

    fun dashobard(): Boolean {
        val intent = Intent(applicationContext, DashboardActivity::class.java)
        startActivity(intent)
        return true
    }

    fun showTags(): Boolean {
        val intent = Intent(applicationContext, ShowTags::class.java)
        startActivity(intent)
        return true

    }

    fun showUsers(): Boolean {

        val intent = Intent(applicationContext, ShowUsers::class.java)
        startActivity(intent)
        return true
    }

    fun Logout(): Boolean {

        val intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
        finish()
        return true
    }
}
