package com.example.demo4

//import pub.devrel.easypermissions.AppSettingsDialog
//import pub.devrel.easypermissions.EasyPermissions
import android.Manifest
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.util.regex.Pattern


class DashboardActivity : AppCompatActivity() {


    lateinit var mAuth: FirebaseAuth
    lateinit var mDatabase: DatabaseReference
    lateinit var showBtn: Button
    lateinit var selectPhotoBtn: Button
    lateinit var postBtn: Button
    lateinit var tags: EditText
    lateinit var postImage: ImageView
    private var imageUri: Uri? = null
    var HashtagFlag: Boolean = false
    var nickname: String = ""


    //lateinit var hashId : String
    companion object {
        private val IMAGE_PICK_CODE = 1000
        private val PERMISSION_CODE = 1001
    }

    lateinit var mStorageRef: StorageReference
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)


        mAuth = FirebaseAuth.getInstance()
        progressDialog = ProgressDialog(this)
        //uID = this.findViewById<TextView>(R.id.uid)
        val uid = mAuth.currentUser?.uid.toString()
        Log.i("tag ", "Current user : $uid")

        mStorageRef = FirebaseStorage.getInstance().getReference()
        mDatabase = FirebaseDatabase.getInstance().getReference()

        //mDatabase = FirebaseDatabase.getInstance().getReference("Users").child(uid)
        //val users = mDatabase.child("Users ").child(uid)

        //var uName =  users.child("name").toString()

        showBtn = findViewById(R.id.showBtn)
        postBtn = findViewById(R.id.postBtn)
        selectPhotoBtn = findViewById(R.id.uploadBtn)
        tags = findViewById(R.id.tags)
        postImage = findViewById(R.id.postImage)


        showBtn.setOnClickListener {


            showPosts()
        }


        selectPhotoBtn.setOnClickListener {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                    //permission denied
                    val permission = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                    //show popup
                    requestPermissions(permission, PERMISSION_CODE)
                } else {
                    //permission already granted

                    pickImage()
                }
            } else {
                //system os is < Marshmallow
                pickImage()
            }

        }

        postBtn.setOnClickListener {

            //checkFunction()
            if (imageUri != null) {
                uploadFile()
            } else {
                Toast.makeText(this, "Select photo", Toast.LENGTH_SHORT).show()
            }

        }
        mDatabase.child("Users").child(uid).addValueEventListener(object : ValueEventListener {

            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(data: DataSnapshot) {

                // var name = data?.child("id")?.value!!.toString().trim()
                // uID.setText(uid)

                var usersInfo = data.getValue(Users::class.java)
                nickname = usersInfo?.nickName.toString()
                Log.e("info", "user nickname : $nickname")

            }

        })
        //Log.i("tag","Name : $uName")
        //Toast.makeText(this, "Id : $uid", Toast.LENGTH_LONG).show()

    }

    // hashtag check separation function
    fun checkFunction() {

        Toast.makeText(this, "Check upload tags", Toast.LENGTH_SHORT).show()

        val str = tags.text.toString().trim()
        val MY_PATTERN = Pattern.compile("(#[A-Za-z0-9-_]+)")
        val mat = MY_PATTERN.matcher(str)
        val strs = ArrayList<String>()
        while (mat.find()) {
            //System.out.println(mat.group(1));
            strs.add(mat.group(0))
            Log.e("tag", "tags: $strs")
        }
        //Log.i("info","string size : ${strs.size}")
        for (hash in strs) {
            Log.e("tag", "Tags: $hash")
        }
    }


    fun pickImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "SELECT IMAGE"), IMAGE_PICK_CODE)

    }

    fun showPosts() {

        val uid = mAuth.currentUser?.uid.toString()
        val showposts = Intent(applicationContext, ShowPosts::class.java)
        showposts.putExtra("userid", uid)
        showposts.putExtra("nickname", nickname)
        startActivity(showposts)

    }

    //handle permission request
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickImage()
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        //super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == IMAGE_PICK_CODE) {
            Toast.makeText(this, "Image selected", Toast.LENGTH_SHORT).show()
            var uri = data?.data.toString()

            if (data != null) {
                imageUri = data.data
            }
            Log.i("tag", "Image : $imageUri")
            postImage.setImageURI(data?.data)
        }
    }

    //upload selected photo and tags
    private fun uploadFile() {

        progressDialog.setMessage("Please wait..")
        progressDialog.show()

        val caption = tags.text.toString().trim()
        if (TextUtils.isEmpty(caption)) {
            tags.error = "Pleas write some caption"
            progressDialog.dismiss()
            return
        }

        if (imageUri != null) {

            Log.i("tag", "path : $imageUri")
            var path: Uri = imageUri as Uri
            val uid = mAuth.currentUser?.uid.toString()
            val ImageUploadId: String = mDatabase.push().getKey().toString()
            mDatabase = FirebaseDatabase.getInstance().getReference()
            //Logic for chunck # from string
            Log.e("tag", "Tags: $caption")

            //hashtag separation
            val str = caption
            val MY_PATTERN = Pattern.compile("(#[A-Za-z0-9-_]+)")
            val mat = MY_PATTERN.matcher(str)
            val strs = ArrayList<String>()
            while (mat.find()) {

                strs.add(mat.group(1))

            }
            // Toast.makeText(this, "Check: $strs", Toast.LENGTH_SHORT).show()

            //Image upload under user and particular folder

            val filepath = mStorageRef.child("Post_images").child(ImageUploadId + ".jpg")

            filepath.putFile(path).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val download_url = task.result.downloadUrl.toString()
                    val post = Posts(ImageUploadId, download_url, caption, uid, strs)

                    mDatabase.child("Users").child(uid).child("Posts").child(ImageUploadId).setValue(post)
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                Toast.makeText(this, "Post Uploaded!!", Toast.LENGTH_SHORT).show()
                                val intent = Intent(applicationContext, DashboardActivity::class.java)
                                startActivity(intent)
                            } else {
                                Toast.makeText(
                                    this, "Post upload failed.Please try again..",
                                    Toast.LENGTH_SHORT
                                ).show()
                                progressDialog.dismiss()
                            }
                        }
                } else {
                    Toast.makeText(
                        this, "Authentication failed.",
                        Toast.LENGTH_SHORT
                    ).show()
                    progressDialog.dismiss()
                }
            }

            Log.i("ta", "Image id : $ImageUploadId")


            //Add hashtags in firebase
            var size = strs.size
            Log.e("info", "size : $size")
            var counter: Int = 1
            var imageCounter: Int = 0
            var imageCounetFalse: Int = 0
            var newImgCounter: Int = 0
            for (hash in strs) {
                //HashtagFlag = false
                Log.e("info", "tag: $hash")
                mDatabase.child("Hashtags").addValueEventListener(object : ValueEventListener {
                    override fun onCancelled(p0: DatabaseError) {
                    }

                    override fun onDataChange(p0: DataSnapshot) {
                        HashtagFlag = false
                        // imageCounetFalse = 0
                        // imageCounter = 1
                        for (db in p0.children) {
                            val hashtagInfo = db.getValue(HashTags::class.java)
                            var hashname: String? = hashtagInfo?.hashtag
                            var hashId: String = hashtagInfo?.hashtagId.toString()

                            if (hashname == hash) {
                                //size = size-1
                                HashtagFlag = true
                                counter += 1
                                imageCounter = 1
                                //newImgCounter = 0
                                //imageCounetFalse = 0

                                Log.e("info", "match data : $hashname | $hash")
                                if (imageCounter == 1 && imageCounetFalse == 0) {
                                    imageCounter = 0
                                    imageCounetFalse = 1
                                    Log.e("info", "insert image : $hashname")
                                }
                                if (imageCounter == 1 && newImgCounter == 1) {
                                    newImgCounter = 0
                                    Log.e("info", "insert after new image : $hashname")
                                }

                            }


                        }


                        if (HashtagFlag == false && counter <= size) {
                            counter++
                            imageCounetFalse = 1
                            newImgCounter = 1
                            Log.e("info", "new data :  $hash $counter")
                            val hashid = mDatabase.push().key.toString()
                            //val hashL = HashTags(hashid,hash,ImageUploadId)
                            //mDatabase.child("Hashtags").child(hashid).setValue(hashL)
                            val filepath = mStorageRef.child("Post_images_posta").child(ImageUploadId + ".jpg")

                            filepath.putFile(path).addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val download_url = task.result.downloadUrl.toString()
                                    val hashList = HashTags(hashid, hash, download_url)

                                    mDatabase.child("Hashtags").child(hashid).setValue(hashList)
                                        .addOnCompleteListener { task ->
                                            if (task.isSuccessful) {
                                                HashtagFlag = true
                                                //val intent = Intent(this@DashboardActivity,DashboardActivity::class.java)
                                                //startActivity(intent)
                                            } else {
                                                Log.e("info", "error ouccur")
                                            }
                                        }

                                }
                            }

                        }
                    }


                })


            }


        } else {
            Toast.makeText(this, "Please select photo!", Toast.LENGTH_SHORT).show()
            return
        }


    }


    //Menu items
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main, menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        var selectedOption = ""
        when (item?.itemId) {

            R.id.itemUsers -> return showUsers()
            R.id.itemTags -> return showTags()
            R.id.home -> return dashobard()
            R.id.itemLogout -> return Logout()
        }
        Toast.makeText(this, "Options: " + selectedOption, Toast.LENGTH_SHORT).show()

        return super.onOptionsItemSelected(item)
    }

    fun dashobard(): Boolean {
        val intent = Intent(applicationContext, DashboardActivity::class.java)
        startActivity(intent)
        return true
    }

    fun showTags(): Boolean {
        val intent = Intent(applicationContext, ShowTags::class.java)
        startActivity(intent)
        return true

    }

    fun showUsers(): Boolean {

        val intent = Intent(applicationContext, ShowUsers::class.java)
        startActivity(intent)
        return true
    }

    fun Logout(): Boolean {

        val intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
        finish()
        return true
    }
}
